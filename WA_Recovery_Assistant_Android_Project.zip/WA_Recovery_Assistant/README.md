# WA Recovery Assistant (Android)

Aplikasi pendamping **tidak resmi** untuk membantu pengguna menyiapkan banding pemblokiran akun WhatsApp secara aman.

## Fitur
- Panduan pengajuan peninjauan melalui WhatsApp dan pusat bantuan resmi.
- Generator pesan banding yang bisa diedit dan disalin.
- Panduan memeriksa status secara manual.
- Riwayat catatan banding yang disimpan lokal di perangkat.

## Privasi dan batasan
- Tidak meminta OTP, PIN, atau kata sandi.
- Tidak mengakses sistem internal WhatsApp, tidak melakukan bypass, dan tidak dapat memulihkan akun secara otomatis.
- Riwayat disimpan di SharedPreferences lokal; jangan mencatat informasi sensitif.
- Tidak ada jaminan banding disetujui.
- Bukan aplikasi resmi atau afiliasi WhatsApp.

## Cara membuka dan membuat APK
1. Pasang Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `WA_Recovery_Assistant`.
4. Tunggu Gradle Sync. Jika diminta, pasang Android SDK Build Tools yang sesuai.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan build
- Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17.
- Project ini disiapkan sebagai sumber Android Studio; APK belum dikompilasi atau diuji pada perangkat di lingkungan ini.
