package id.bree.wa_recovery_assistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PREFS = "wa_recovery_local"
private const val HISTORY_KEY = "appeal_history"

data class AppealRecord(val date: String, val phone: String, val note: String, val status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RecoveryApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecoveryApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var phone by remember { mutableStateOf("") }
    var accountName by remember { mutableStateOf("") }
    var extraInfo by remember { mutableStateOf("") }
    var appealText by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(loadHistory(context)) }
    var statusExpanded by remember { mutableStateOf(false) }
    var chosenStatus by remember { mutableStateOf("Menunggu") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF087F5B),
            secondary = androidx.compose.ui.graphics.Color(0xFF5A8F7B)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("WA Recovery Assistant", fontWeight = FontWeight.Bold)
                            Text("Pendamping banding resmi", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            openUrl(context, "https://www.whatsapp.com/contact/")
                        }) { Icon(Icons.Default.OpenInNew, contentDescription = "Buka bantuan resmi") }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("Beranda") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.EditNote, contentDescription = null) },
                        label = { Text("Buat banding") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.History, contentDescription = null) },
                        label = { Text("Riwayat") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Akun WhatsApp diblokir?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("Aplikasi ini membantu menyiapkan banding dan mencatat perkembangannya. Hanya WhatsApp yang dapat memutuskan pemulihan akun.")
                                Button(onClick = { selectedTab = 1 }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.Edit, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Siapkan pesan banding")
                                }
                            }
                        }
                        SectionCard("Langkah pemulihan resmi") {
                            StepText("1", "Buka WhatsApp resmi dan coba masuk menggunakan nomor yang diblokir.")
                            StepText("2", "Pada layar pemberitahuan pemblokiran, pilih opsi “Minta peninjauan” jika tersedia.")
                            StepText("3", "Jelaskan situasi dengan jujur dan sertakan nomor dalam format internasional.")
                            StepText("4", "Tunggu hasil di aplikasi WhatsApp atau melalui kanal dukungan resmi.")
                            OutlinedButton(
                                onClick = { openUrl(context, "https://www.whatsapp.com/contact/") },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Buka Pusat Bantuan WhatsApp") }
                        }
                        SectionCard("Penting untuk keamanan") {
                            Bullet("Jangan berikan kode OTP, PIN verifikasi dua langkah, atau kata sandi kepada siapa pun.")
                            Bullet("Hindari aplikasi pihak ketiga yang menjanjikan unban instan.")
                            Bullet("Jika memakai aplikasi WhatsApp modifikasi, hapus dan gunakan aplikasi resmi.")
                            Bullet("Banding tidak menjamin akun akan dipulihkan.")
                        }
                        SectionCard("Panduan cek status") {
                            Text("Buka WhatsApp resmi dan ikuti petunjuk di layar. Jika pengajuan sedang ditinjau, tunggu pemberitahuan atau hubungi dukungan resmi. Aplikasi ini tidak dapat membaca status akun secara otomatis.")
                        }
                    }
                    1 -> {
                        Text("Generator pesan banding", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Isi data secukupnya. Data tetap disimpan di perangkat ini dan tidak dikirim otomatis.")
                        OutlinedTextField(
                            value = phone, onValueChange = { phone = it },
                            label = { Text("Nomor WhatsApp (format internasional)") },
                            placeholder = { Text("+62xxxxxxxxxx") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = accountName, onValueChange = { accountName = it },
                            label = { Text("Nama (opsional)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = extraInfo, onValueChange = { extraInfo = it },
                            label = { Text("Keterangan singkat (opsional)") },
                            placeholder = { Text("Misalnya: akun pribadi dan dugaan penyebab pemblokiran") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                        Button(
                            onClick = {
                                val nameLine = if (accountName.isBlank()) "" else "Nama: ${accountName.trim()}\n"
                                val detailLine = if (extraInfo.isBlank()) "" else "\nKeterangan: ${extraInfo.trim()}\n"
                                appealText = "Halo Tim Dukungan WhatsApp,\n\nSaya ingin meminta peninjauan atas pemblokiran akun WhatsApp saya dengan nomor ${phone.trim()}.\n$nameLineSaya mohon agar akun saya ditinjau kembali. Jika ada aktivitas yang melanggar Ketentuan Layanan, saya bersedia memahami aturan yang berlaku dan mengambil langkah yang diperlukan.$detailLineTerima kasih atas waktu dan bantuannya."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Icon(Icons.Default.AutoFixHigh, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Buat pesan banding") }

                        if (appealText.isNotBlank()) {
                            OutlinedTextField(
                                value = appealText, onValueChange = { appealText = it },
                                label = { Text("Pesan banding — periksa sebelum dikirim") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 8
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Pesan banding WhatsApp", appealText))
                                        Toast.makeText(context, "Pesan disalin", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Icon(Icons.Default.ContentCopy, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Salin") }
                                Button(
                                    onClick = {
                                        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                                        val record = AppealRecord(date, phone.trim(), "Pesan banding dibuat", chosenStatus)
                                        history = listOf(record) + history
                                        saveHistory(context, history)
                                        Toast.makeText(context, "Dicatat di riwayat perangkat", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Catat") }
                            }
                            Text("Kirim pesan melalui opsi peninjauan di WhatsApp atau kanal resmi yang sesuai. Jangan mengirim berulang kali secara berlebihan.")
                        }
                    }
                    else -> {
                        Text("Riwayat banding", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Riwayat hanya tersimpan secara lokal di perangkat ini.")
                        if (history.isEmpty()) {
                            Card { Text("Belum ada catatan. Buat pesan banding lalu tekan Catat.", Modifier.padding(16.dp)) }
                        } else {
                            history.forEachIndexed { index, record ->
                                Card {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(record.date, fontWeight = FontWeight.Bold)
                                        Text("Nomor: ${record.phone.ifBlank { "Tidak dicantumkan" }}")
                                        Text(record.note)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Status: ")
                                            Box {
                                                OutlinedButton(onClick = { statusExpanded = true }) { Text(record.status); Icon(Icons.Default.ArrowDropDown, contentDescription = null) }
                                                DropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                                                    listOf("Menunggu", "Dikirim", "Ditinjau", "Selesai", "Ditolak").forEach { status ->
                                                        DropdownMenuItem(text = { Text(status) }, onClick = {
                                                            history = history.toMutableList().also { it[index] = record.copy(status = status) }
                                                            saveHistory(context, history)
                                                            statusExpanded = false
                                                        })
                                                    }
                                                }
                                            }
                                        }
                                        TextButton(onClick = {
                                            history = history.filterIndexed { i, _ -> i != index }
                                            saveHistory(context, history)
                                        }) { Icon(Icons.Default.DeleteOutline, contentDescription = null); Text("Hapus catatan") }
                                    }
                                }
                            }
                        }
                        OutlinedButton(onClick = {
                            history = emptyList()
                            saveHistory(context, history)
                        }, modifier = Modifier.fillMaxWidth()) { Text("Hapus semua riwayat") }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Bukan aplikasi resmi WhatsApp. Tidak ada akses ke sistem internal WhatsApp atau pemeriksaan status otomatis.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        })
    }
}

@Composable
private fun StepText(number: String, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.secondaryContainer) {
            Text(number, Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontWeight = FontWeight.Bold)
        }
        Text(text, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun Bullet(text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
        Text("•")
        Text(text, modifier = Modifier.weight(1f))
    }
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: Exception) {
        Toast.makeText(context, "Tidak dapat membuka tautan", Toast.LENGTH_SHORT).show()
    }
}

private fun loadHistory(context: Context): List<AppealRecord> {
    return try {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HISTORY_KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            AppealRecord(obj.optString("date"), obj.optString("phone"), obj.optString("note"), obj.optString("status", "Menunggu"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveHistory(context: Context, records: List<AppealRecord>) {
    val array = JSONArray()
    records.forEach { record ->
        array.put(JSONObject().apply {
            put("date", record.date)
            put("phone", record.phone)
            put("note", record.note)
            put("status", record.status)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(HISTORY_KEY, array.toString()).apply()
}
